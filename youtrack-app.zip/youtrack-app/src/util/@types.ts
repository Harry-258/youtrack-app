export interface YouTrackProject {
    name: string;
    id: string;
}
